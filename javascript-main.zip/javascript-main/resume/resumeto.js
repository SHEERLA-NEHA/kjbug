let body1 = document.querySelector("body");
let head = document.querySelector("header");
let h = document.querySelector("h1");
let pp = document.querySelectorAll("section");
let hh = document.querySelectorAll("h2");
let i = document.querySelectorAll("li");
let ull = document.querySelectorAll("ul");
let str = document.querySelectorAll("strong");
let p = document.querySelectorAll("p");
let but = document.getElementById("bu");

but.addEventListener("click", () => {
    body1.classList.toggle("pbody");
    h.classList.toggle("text");

    p.forEach((paragraph) => {
        paragraph.classList.toggle("text");
    });
    pp.forEach((section) => {
        section.classList.toggle("text");
    });
    hh.forEach((heading) => {
        heading.classList.toggle("text");
    });
    ull.forEach((ul) => {
        ul.classList.toggle("text");
    });
    str.forEach((boldText) => {
        boldText.classList.toggle("text");
    });
    i.forEach((listItem) => {
        listItem.classList.toggle("text");
    });
});
